<p>
<font size="2" face="%HTMLFONT%"><b>Instru��es de pagamento: </b>
<ul>
  <li>Caso voce n�o queira imprimir o boleto banc�rio, ou prefira pagar pelo Home Banking, utilize as seguintes informa��es:<p></li>
  <li>linha digitada: <b>%LINHA%</b></li> 
  <li>valor: <b>R$ %VDOC%</b></li> 
</ul>
</font>
</p>

<hr>
<br>
<a href="%PDF_LINK%">Clique aqui para abrir o boleto em formato PDF</a>
