<p>
<font size="2" face="%HTMLFONT%"><b>Instru��es de pagamento: </b>
<ul>
  <li>Caso voce n�o queira imprimir o boleto banc�rio, ou prefira pagar pelo Home Banking, utilize as seguintes informa��es:<p></li>
  <li>linha digitada: <b>%LINHA%</b></li> 
  <li>valor: <b>R$ %VDOC%</b></li> 
</ul>
</font>
</p>

<hr>

<EMBED SRC="%BOLETO_URL%svg.php?img=%IMG_FILENAME%&iesucks=yes" WIDTH="640" HEIGHT="560" PLUGINSPAGE="http://www.adobe.com/svg/viewer/install/">
<br>
<center>
  <font size="1">
  Nota: Se voc� n�o tem suporte a gr�ficos SVG no seu browser, por favor visite a p�gina abaixo:<br>
  <a href="http://www.adobe.com/svg/viewer/install/">http://www.adobe.com/svg/viewer/install/</a>
  </font>
</center>
