<?php
/* vim: set expandtab tabstop=4 shiftwidth=4: */
// +----------------------------------------------------------------------+
// | phpBoleto v2.0                                                       |
// +----------------------------------------------------------------------+
// | Copyright (c) 1999-2001 Pablo Martins F. Costa, Jo�o Prado Maia      |
// +----------------------------------------------------------------------+
// | Este arquivo est� sujeito a vers�o 2 da GNU General Public License,  |
// | que foi adicionada nesse pacote no arquivo COPYING e est� dispon�vel |
// | pela Web em http://www.gnu.org/copyleft/gpl.txt                      |
// | Voc� deve ter recebido uma c�pia da GNU Public License junto com     |
// | esse pacote; se n�o, escreva para:                                   |
// |                                                                      |
// | Free Software Foundation, Inc.                                       |
// | 59 Temple Place - Suite 330                                          |
// | Boston, MA 02111-1307, USA.                                          |
// +----------------------------------------------------------------------+
// | Autores: Jo�o Prado Maia <jpm@phpbrasil.com>                         |
// +----------------------------------------------------------------------+
//
// @(#) $Id: class.postscript.php,v 1.2 2001/12/18 22:19:57 jcpm Exp $
//


// Talvez uma id�ia para o futuro para tentar liberar a gera��o do Boleto
// em formato PDF pelo formato aberto PostScript.
//
// Vilson G�rtner do Codigoaberto.org.br administra um projeto para a 
// cria��o de um m�dulo de extens�o para PostScript similar ao do PDF, e
// pode ser a sa�da para o problema do PDFlib, que � um aplicativo 
// comercial e muito caro.

?>