<?php
/* $Id: merge.lib.php,v 1.1 2005/12/07 10:49:43 cybot_tm Exp $ */
// vim: expandtab sw=4 ts=4 sts=4:

class PMA_StorageEngine_merge extends PMA_StorageEngine
{
}

?>
